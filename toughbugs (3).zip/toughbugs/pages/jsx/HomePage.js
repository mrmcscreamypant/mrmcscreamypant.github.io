import ThemeStyle from '../../styles/global';
import { Text, SafeAreaView, View} from 'react-native';
import { Link } from "react-router-dom";
import Header from '../../api/Header';

const styles = ThemeStyle();

function HomePage() {
  return (
    <SafeAreaView style={styles.container}>
      <Header>
        <View style={styles.navLinkContainer}>
          <Link to={"/about"} style={styles.navLink}>About</Link>
          <Link to={"/download"} style={styles.navLink}>Download</Link>
        </View>
      </Header>
    </SafeAreaView>
  );
}

export default HomePage;
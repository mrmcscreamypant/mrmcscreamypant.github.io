import ThemeStyle from '../../styles/global';
import { Text, SafeAreaView, View} from 'react-native';
import { Link } from "react-router-dom";
import BackLink from '../../api/BackLink';

const styles = ThemeStyle();

function Error404() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>
        ToughBugs
      </Text>
      <Text style={styles.motd}>
        404Error
      </Text>
      <BackLink />
    </SafeAreaView>
  );
}

export default Error404;
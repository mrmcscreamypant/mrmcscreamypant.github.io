import ThemeStyle from '../../styles/global';
import {Text, SafeAreaView, View} from 'react-native';
import { Link } from "react-router-dom";
import BackLink from '../../api/BackLink';
import Header from '../../api/Header'

const styles = ThemeStyle();

function AboutPage() {
  return (
    <SafeAreaView style={styles.container}>
      <Header>
        <Text style={styles.paragraph}>
          This is a webpage that is pure nonsense where I tell you nothing of value
        </Text>
      </Header>
      <BackLink />
    </SafeAreaView>
  );
}

export default AboutPage;
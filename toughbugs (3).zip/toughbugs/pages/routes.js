import { Routes, Route } from "react-router-dom";

import HomePage from "./jsx/HomePage";
import AboutPage from './jsx/AboutPage';
import Error404 from './jsx/Error404'

function RouteSystem() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />}/>
      <Route path="/about" element={<AboutPage />} />
      <Route path="/download" element={<Error404 />} />
    </Routes>
  );
}

export default RouteSystem;
import { HashRouter as Router } from "react-router-dom";
import RouteSystem from './pages/routes'

export default function App() {
  return (
    <Router>
      <RouteSystem />
    </Router>
  )
}
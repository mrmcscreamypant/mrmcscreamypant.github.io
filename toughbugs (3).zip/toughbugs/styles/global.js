import LightTheme from './LightTheme.js';

function ThemeStyle() {
  return LightTheme();
}

export default ThemeStyle;
import {StyleSheet} from 'react-native';

function LightTheme() {
  return StyleSheet.create({
    container: {
      backgroundColor: '#ecf0f1',
      padding: 8,
      flex: 1,
      flexDirection: "column",
      height: '100%',
    },
    motd: {
      margin: 0,
      fontSize: 18,
      fontWeight: 'light',
      textAlign: 'center',
    },
    title: {
      margin: 12,
      fontSize: 36,
      fontWeight: "bold",
      textAlign: 'center',
    },
    navLinkContainer: {
      textAlign: 'center',
      flexDirection: 'row',
      margin: 12,
    },
    navLink: {
      color: "#101010",
      flex: 1,
    },
    backLinkContainer: {
      textAlign: 'center',
      flex: 0.05,
    },
    backLink: {
      color: '#101010',
      flex: 1,
    },
    headerContainer: {
      flex:1,
    }
  });
}

export default LightTheme;
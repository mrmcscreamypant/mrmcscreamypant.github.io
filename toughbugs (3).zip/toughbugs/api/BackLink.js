import ThemeStyle from '../styles/global';
import { View} from 'react-native';
import { Link } from "react-router-dom";

const styles = ThemeStyle();

function BackLink() {
  return (
    <View style={styles.backLinkContainer}>
      <Link to={"/"} style={styles.backLink}>Back</Link>
    </View>
  );
}

export default BackLink
import ThemeStyle from '../styles/global';
import {Text} from 'react-native';

const styles = ThemeStyle();

const motds = [
  "Hello world",
  "No Bugs",
  "Gluten Free",
  "2% Sugar",
  "That's no moon!"
]

function motdText() {
  const i = Math.floor(Math.random() * motds.length);
  return motds[i];
}

function Motd() {
  return (
    <Text style={styles.motd}>
      {motdText()}
    </Text>
  );
}

export default Motd;
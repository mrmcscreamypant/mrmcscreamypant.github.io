import ThemeStyle from '../styles/global';
import { Text, View} from 'react-native';
import Motd from '../api/Motd';

const styles = ThemeStyle();

function Header({ children }) {
  return (
    <View style={styles.headerContainer}>
      <Text style={styles.title}>
        ToughBugs
      </Text>
      <Motd />
      {children}
    </View>
  );
}

export default Header;